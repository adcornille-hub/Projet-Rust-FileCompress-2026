# Compresseur MAL (MaxAdLe)

Compresseur de fichiers autonome développé en Rust avec format d'archive personnalisé `.mal`.

## Description

Le compresseur MAL utilise l'algorithme DEFLATE (LZ77 + Huffman) pour compresser des fichiers avec vérification d'intégrité CRC32. Il supporte la compression multi-fichiers avec exploration récursive des dossiers.

**Caractéristiques principales :**
- Compression DEFLATE avec 10 niveaux (0-9)
- Support multi-fichiers et dossiers récursifs
- Vérification d'intégrité CRC32
- Barres de progression en temps réel
- Interface CLI colorée et intuitive
- **Entièrement autonome** - aucune installation requise
- Organisation automatique (dossiers `compressed/` et `decompressed/`)

---

## Installation pour Utilisateurs Finaux

### **Téléchargement**

1. Téléchargez l'archive correspondant à votre système depuis le site web
2. Extrayez l'archive

### **Première utilisation**

**Linux / macOS :**
```bash
# Extraire l'archive
tar -xzf mal-compressor-*.tar.gz
cd mal-compressor-*

# Rendre les scripts exécutables (une seule fois)
chmod +x *.sh mal

# Tester
echo "Hello MAL!" > test.txt
./compress.sh test.txt
./decompress.sh compressed/test.mal
```

**Windows :**
```cmd
# Extraire le fichier .zip
# Ouvrir l'invite de commande dans le dossier extrait

# Tester
echo Hello MAL! > test.txt
mal.exe compress test.txt
mal.exe decompress compressed\test.mal
```

**C'est tout ! Aucune installation supplémentaire nécessaire.**

---

## Guide d'Utilisation

### **Méthode Simple : Scripts (Linux/macOS)**

#### **Compression**
```bash
# Compresser un fichier → crée compressed/fichier.mal
./compress.sh fichier.txt

# Compresser un dossier → crée compressed/dossier.mal
./compress.sh dossier/

# Compresser plusieurs fichiers → crée compressed/compressedfiles.mal
./compress.sh file1.txt file2.txt file3.txt

# Compression maximale
./compress.sh -l 9 fichier.txt

# Nom personnalisé
./compress.sh -o monarchive.mal fichier.txt
```

#### **Décompression**
```bash
# Décompresser → extrait dans decompressed/
./decompress.sh compressed/archive.mal

# Destination personnalisée
./decompress.sh compressed/archive.mal -o destination/
```

#### **Vérification**
```bash
# Vérifier l'intégrité d'une archive
./verify.sh compressed/archive.mal
```

---

### **Méthode Directe : Exécutable**

#### **Compression**
```bash
# Syntaxe de base (nom de sortie automatique)
./mal compress <fichiers/dossiers>

# Avec nom personnalisé
./mal compress <fichiers/dossiers> -o <archive.mal>

# Exemples
./mal compress fichier.txt                    # Crée compressed/fichier.mal
./mal compress dossier/                       # Crée compressed/dossier.mal
./mal compress file1.txt file2.txt            # Crée compressed/compressedfiles.mal
./mal compress fichier.txt -o custom.mal      # Crée compressed/custom.mal
./mal compress fichier.txt -l 9               # Compression max
```

**Nommage automatique :**
- **Un fichier** : `fichier.txt` → `compressed/fichier.mal`
- **Un dossier** : `dossier/` → `compressed/dossier.mal`
- **Plusieurs fichiers** : `file1.txt file2.txt` → `compressed/compressedfiles.mal`
- **Si existe déjà** : `fichier.mal` → `fichier-1.mal` → `fichier-2.mal`

**Niveaux de compression :**
- `0` : Aucune compression (stockage seul)
- `1` : Compression la plus rapide
- `6` : **Par défaut** - bon équilibre vitesse/ratio
- `9` : Compression maximale (plus lent)

#### **Décompression**
```bash
./mal decompress compressed/archive.mal           # Vers decompressed/
./mal decompress compressed/archive.mal -o dest/  # Vers dest/
```

#### **Lister le contenu**
```bash
./mal list compressed/archive.mal
```

Affiche :
- Version et niveau de compression
- Nombre de fichiers
- Tailles originales et compressées
- Ratios de compression par fichier

#### **Vérifier l'intégrité**
```bash
./mal verify compressed/archive.mal
```

Vérifie tous les fichiers via CRC32 et affiche les erreurs éventuelles.

#### **Aide**
```bash
./mal --help                  # Aide générale
./mal compress --help         # Aide compression
./mal decompress --help       # Aide décompression
```

---

## Exemples d'Utilisation

### **Exemple 1 : Sauvegarder un projet**

```bash
# Compresser votre projet
./compress.sh -l 9 mon_projet/

# Résultat : compressed/mon_projet.mal

# Vérifier
./mal list compressed/mon_projet.mal

# Restaurer plus tard
./decompress.sh compressed/mon_projet.mal
# Fichiers dans : decompressed/mon_projet/
```

### **Exemple 2 : Partager des documents**

```bash
# Compresser plusieurs fichiers
./compress.sh rapport.pdf presentation.pptx donnees.xlsx

# Résultat : compressed/compressedfiles.mal

# Partager l'archive
# Le destinataire extrait avec :
./decompress.sh compressedfiles.mal
```

### **Exemple 3 : Compressions multiples**

```bash
# Première compression
./compress.sh document.txt
# → compressed/document.mal

# Modifier et recompresser
echo "Version 2" >> document.txt
./compress.sh document.txt
# → compressed/document-1.mal

# Modifier et recompresser encore
echo "Version 3" >> document.txt
./compress.sh document.txt
# → compressed/document-2.mal

# Vous avez maintenant 3 versions !
ls -lh compressed/document*.mal
```

### **Exemple 4 : Fichiers très répétitifs**

```bash
# Créer un fichier très répétitif
for i in {1..1000}; do 
    echo "Cette ligne se répète 1000 fois" >> repetitif.txt
done

# Taille : ~40 KB
ls -lh repetitif.txt

# Compresser
./compress.sh repetitif.txt

# Voir le résultat
./mal list compressed/repetitif.mal
# Ratio : ~5% (95% de compression !)
```

---

## Structure des Dossiers

Après utilisation, votre espace de travail ressemble à :

```
votre-dossier/
├── compressed/              ← Archives créées automatiquement
│   ├── fichier.mal
│   ├── fichier-1.mal
│   ├── projet.mal
│   └── ...
├── decompressed/            ← Fichiers extraits automatiquement
│   ├── fichier.txt
│   ├── projet/
│   │   ├── src/
│   │   └── README.md
│   └── ...
├── mal                      ← Exécutable (Linux/macOS)
├── mal.exe                  ← Exécutable (Windows)
├── compress.sh              ← Script de compression
├── decompress.sh            ← Script de décompression
├── verify.sh                ← Script de vérification
└── README.md                ← Ce fichier
```

---

## Format du fichier `.mal`

```
┌─────────────────────────────────┐
│ Header (taille variable)       │
│  - Magic number: "MAL\0"       │
│  - Version: 1                  │
│  - Niveau de compression       │
│  - Nombre de fichiers          │
│  - Tailles totales             │
├─────────────────────────────────┤
│ Index des fichiers             │
│  - Chemins relatifs            │
│  - Tailles originales          │
│  - Tailles compressées         │
│  - CRC32 de chaque fichier     │
├─────────────────────────────────┤
│ Données compressées            │
│  - Fichier 1 (DEFLATE)         │
│  - Fichier 2 (DEFLATE)         │
│  - ...                         │
└─────────────────────────────────┘
```

---

## Algorithmes Utilisés

### **DEFLATE**
Combinaison de deux algorithmes complémentaires :
- **LZ77** : Compression par dictionnaire avec fenêtre glissante de 32 KB
- **Huffman dynamique** : Codage entropique adaptatif

### **CRC32**
Chaque fichier est protégé par une somme de contrôle **CRC32** calculée sur les données non compressées, garantissant :
- Détection de 100% des erreurs simples et doubles
- Détection de tous les bursts d'erreurs ≤ 32 bits

---

## Performance

**Vitesse de compression typique :**
- Niveau 1 : ~100-200 MB/s
- Niveau 6 : ~50-80 MB/s  
- Niveau 9 : ~10-30 MB/s

**Ratios de compression observés :**
- Texte répétitif : jusqu'à 95%+
- Code source : ~60-80%
- Documents : ~40-60%
- Données aléatoires/binaires : ~0% (non compressible)

---

## FAQ

**Q : Dois-je installer Rust pour utiliser MAL ?**  
R : Non ! L'exécutable contient tout ce qui est nécessaire.

**Q : Les archives `.mal` sont-elles compatibles entre Linux/Windows/macOS ?**  
R : Oui, totalement ! Le format est identique sur toutes les plateformes.

**Q : Que faire si un fichier existe déjà lors de la compression ?**  
R : MAL ajoute automatiquement un suffixe numérique (`-1`, `-2`, etc.).

**Q : Puis-je compresser des fichiers déjà compressés (ZIP, JPG, etc.) ?**  
R : Oui, mais le ratio sera faible car ces formats sont déjà optimisés.

---

## Pour les Développeurs

Si vous voulez compiler depuis les sources :

### **Installation de Rust**

**Linux / macOS :**
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env
```

**Windows :**  
Téléchargez : https://win.rustup.rs/

### **Compilation**

```bash
# Cloner ou télécharger le code source
cd mal-compressor/

# Compiler en mode release
cargo build --release

# L'exécutable sera dans target/release/mal
```

### **Structure du Code**

```
src/
├── main.rs          # Point d'entrée CLI
├── lib.rs           # Module principal
├── archive.rs       # Structures de données
├── compression.rs   # Logique de compression/décompression
└── utils.rs         # Fonctions utilitaires
```

### **Commandes de développement**

```bash
# Formater le code
cargo fmt

# Vérifier le style
cargo clippy

# Exécuter les tests
cargo test

# Nettoyer
cargo clean
```

---

## Équipe de Développement

- **Léos** - Architecture et format de fichier
- **Adrien** - Compression et vérification d'intégrité
- **Maxime** - Interface CLI et visualisation

---

## Licence

Projet académique - EPITA

---

## Ressources Techniques

- [Documentation Rust](https://doc.rust-lang.org/)
- [RFC 1951 - DEFLATE](https://datatracker.ietf.org/doc/html/rfc1951)
- [CRC32 Algorithm](https://en.wikipedia.org/wiki/Cyclic_redundancy_check)
- [LZ77 Compression](https://en.wikipedia.org/wiki/LZ77_and_LZ78)
- [Huffman Coding](https://en.wikipedia.org/wiki/Huffman_coding)

---

## Support

Pour toute question ou problème :
1. Consultez la section FAQ ci-dessus
2. Utilisez `./mal --help` pour l'aide intégrée
3. Contactez l'équipe de développement

**Version : 1.0.0**